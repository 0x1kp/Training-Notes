
![](https://academy.hackthebox.com/storage/modules/229/Internet.png)

Telnet is a network protocol that allows a bidirectional interactive communication session between two devices over a network. This protocol was developed in the 1970s and was defined in RFC 854. As of recent years, its usage has decreased significantly as opposed to SSH.

In many older cases, such as our Windows NT like machines, they may still utilize telnet to provide remote command and control to microsoft terminal services.

However, we should always watch for weird and strange telnet communications as it can also be used by attackers for malicious purposes such as data exfiltration and tunneling.

## Finding Traditional Telnet Traffic Port 23

**Related PCAP File(s)**:

- `telnet_tunneling_23.pcapng`

Suppose we were to open Wireshark, we might notice some telnet communications originating from Port 23. In this case, we can always inspect this traffic further.

![Telnet](https://academy.hackthebox.com/storage/modules/229/1-telnet.png)

Fortunately for us, telnet traffic tends to be decrypted and easily inspectable, but like ICMP, DNS, and other tunneling methods, attackers may encrypt, encode, or obfuscate this text. So we should always be careful.

![Telnet](https://academy.hackthebox.com/storage/modules/229/2-telnet.png)

## Unrecognized TCP Telnet in Wireshark

**Related PCAP File(s)**:

- `telnet_tunneling_9999.pcapng`

Telnet is just a communication protocol, and as such can be easily switched to another port by an attacker. Keeping an eye on these strange port communications can allow us to find potentially malicious actions. Lets take the following for instance.

![Telnet](https://academy.hackthebox.com/storage/modules/229/3-telnet.png)

We may see a ton of communications from one client on port 9999. We can dive into this a little further by looking at the contents of these communications.

![Telnet](https://academy.hackthebox.com/storage/modules/229/4-telnet.png)

If we noticed something like above, we would want to follow this TCP stream.

![Telnet](https://academy.hackthebox.com/storage/modules/229/5-telnet.png)

Doing so can allow us to inspect potentially malicious actions.

## Telnet Protocol through IPv6

**Related PCAP File(s)**:

- `telnet_tunneling_ipv6.pcapng`

After all, unless our local network is configured to utilize IPv6, observing IPv6 traffic can be an indicator of bad actions within our environment. We might notice the usage of IPv6 addresses for telnet like the following.

![Telnet](https://academy.hackthebox.com/storage/modules/229/6-telnet.png)

We can narrow down our filter in Wireshark to only show telnet traffic from these addresses with the following filter.

- `((ipv6.src_host == fe80::c9c8:ed3:1b10:f10b) or (ipv6.dst_host == fe80::c9c8:ed3:1b10:f10b)) and telnet`

![Telnet](https://academy.hackthebox.com/storage/modules/229/7-telnet.png)

Likewise, we can inspect the contents of these packets through their data field, or by following the TCP stream.

![Telnet](https://academy.hackthebox.com/storage/modules/229/8-telnet.png)