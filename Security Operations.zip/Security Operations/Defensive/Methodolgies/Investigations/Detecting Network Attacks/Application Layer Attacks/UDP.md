## Watching UDP Communications


![TCP vs UDP](https://academy.hackthebox.com/storage/modules/229/udp-tcp.jpg)

One of the biggest distinguishing aspects between TCP and UDP is that UDP is connectionless and provides fast transmission. Let's take the following traffic for instance.

![UDP](https://academy.hackthebox.com/storage/modules/229/1-udp.png)

We will notice that instead of a SYN, SYN/ACK, ACK sequence, the communications are immediately sent over to the recipient. Like TCP, we can follow UDP traffic in Wireshark, and inspect its contents.

![UDP](https://academy.hackthebox.com/storage/modules/229/2-udp.png)

## Common Uses of UDP

UDP although less reliable than TCP provides quicker connections through its connectionless state. As such, we might find legitimate traffic that uses UDP like the following:

|**Step**|**Description**|
|---|---|
|`1. Real-time Applications`|Applications like streaming media, online gaming, real-time voice and video communications|
|`2. DNS (Domain Name System)`|DNS queries and responses use UDP|
|`3. DHCP (Dynamic Host Configuration Protocol)`|DHCP uses UDP to assign IP addresses and configuration information to network devices.|
|`4. SNMP (Simple Network Management Protocol)`|SNMP uses UDP for network monitoring and management|
|`5. TFTP (Trivial File Transfer Protocol)`|TFTP uses UDP for simple file transfers, commonly used by older Windows systems and others.|
