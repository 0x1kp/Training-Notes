# Relevant Pages
[[Security Operations/General/Concepts/Networking/Protocols/ARP|ARP]]

## ARP Poisoning & Spoofing

In an ideal scenario, robust controls would be in place to thwart these attacks, but in reality, this isn't always feasible. To comprehend our Indicators of Compromise (IOCs) more effectively, let's delve into the behavior of ARP Poisoning and Spoofing attacks.

![ARP Cache Poisoning](https://academy.hackthebox.com/storage/modules/229/ARP-spoofing-poisoning.png)

Detecting these attacks can be challenging, as they mimic the communication structure of standard ARP traffic. Yet, certain ARP requests and replies can reveal their nefarious nature. Let's illustrate how these attacks function, enabling us to better identify them during our traffic analysis.

|**Step**|**Description**|
|---|---|
|`1`|Consider a network with three machines: the victim's computer, the router, and the attacker's machine.|
|`2`|The attacker initiates their ARP cache poisoning scheme by dispatching counterfeit ARP messages to both the victim's computer and the router.|
|`3`|The message to the victim's computer asserts that the gateway's (router's) IP address corresponds to the physical address of the attacker's machine.|
|`4`|Conversely, the message to the router claims that the IP address of the victim's machine maps to the physical address of the attacker's machine.|
|`5`|On successfully executing these requests, the attacker may manage to corrupt the ARP cache on both the victim's machine and the router, causing all data to be misdirected to the attacker's machine.|
|`6`|If the attacker configures traffic forwarding, they can escalate the situation from a denial-of-service to a man-in-the-middle attack.|
|`7`|By examining other layers of our network model, we might discover additional attacks. The attacker could conduct DNS spoofing to redirect web requests to a bogus site or perform SSL stripping to attempt the interception of sensitive data in transit.|

Detecting these attacks is one aspect, but averting them is a whole different challenge. We could potentially fend off these attacks with controls such as:

1. `Static ARP Entries`: By disallowing easy rewrites and poisoning of the ARP cache, we can stymie these attacks. This, however, necessitates increased maintenance and oversight in our network environment.
2. `Switch and Router Port Security`: Implementing network profile controls and other measures can ensure that only authorized devices can connect to specific ports on our network devices, effectively blocking machines attempting ARP spoofing/poisoning.

## Installing & Starting TCPDump

To effectively capture this traffic, especially in the absence of configured network monitoring software, we can employ tools like `tcpdump` and `Wireshark`, or simply `Wireshark` for Windows hosts.

We can typically find `tcpdump` located in `/usr/sbin/tcpdump`. However, if the tool isn't installed, it can be installed using the appropriate command, which will be provided based on the specific system requirements.

#### [[Tcpdump]]

```shell-session
ukejelam@htb[/htb]$ sudo apt install tcpdump -y
```

To initiate the traffic capture, we can employ the command-line tool `tcpdump`, specifying our network interface with the `-i` switch, and dictating the name of the output capture file using the `-w` switch.

```shell-session
ukejelam@htb[/htb]$ sudo tcpdump -i eth0 -w filename.pcapng
```

## Finding ARP Spoofing

For detecting ARP Spoofing attacks, we'll need to open the related traffic capture file (`ARP_Spoof.pcapng`) from this module's resources using Wireshark.

  ARP Spoofing & Abnormality Detection

```shell-session
ukejelam@htb[/htb]$ wireshark ARP_Spoof.pcapng
```

Once we've navigated to Wireshark, we can streamline our view to focus solely on ARP requests and replies by employing the filter `arp.opcode`.

![ARP Spoofing Detection](https://academy.hackthebox.com/storage/modules/229/ARP_Spoof_1.png)

A key red flag we need to monitor is any anomaly in traffic emanating from a specific host. For instance, one host incessantly broadcasting ARP requests and replies to another host could be a telltale sign of ARP spoofing.

In such a scenario, we might identify that the MAC address `08:00:27:53:0C:BA is behaving suspiciously`.

To ascertain this, we can fine-tune our analysis to inspect solely the interactions—both requests and replies—among the attacker's machine, the victim's machine, and the router. The opcode functionality in `Wireshark` can simplify this process.

1. `Opcode == 1`: This represents all types of ARP Requests
2. `Opcode == 2`: This signifies all types of ARP Replies

As a preliminary step, we could scrutinize the requests dispatched using the following filter.

- `arp.opcode == 1`

![ARP Spoofing Detection](https://academy.hackthebox.com/storage/modules/229/ARP_Spoof_2.png)

Almost instantly, we should notice a red flag - an address duplication, accompanied by a warning message. If we delve into the details of the error message within Wireshark, we should be able to extract additional information.

![ARP Spoofing Detection](https://academy.hackthebox.com/storage/modules/229/ARP_Spoof_3.png)

Upon immediate inspection, we might discern that one IP address is mapped to two different MAC addresses. We can validate this on a Linux system by executing the appropriate commands.

#### ARP


```shell-session
ukejelam@htb[/htb]$ arp -a | grep 50:eb:f6:ec:0e:7f

? (192.168.10.4) at 50:eb:f6:ec:0e:7f [ether] on eth0
```

```shell-session
ukejelam@htb[/htb]$ arp -a | grep 08:00:27:53:0c:ba

? (192.168.10.4) at 08:00:27:53:0c:ba [ether] on eth0
```

In this situation, we might identify that our ARP cache, in fact, contains both MAC addresses allocated to the same IP address - an anomaly that warrants our immediate attention.

To sift through more duplicate records, we can utilize the subsequent Wireshark filter.

- `arp.duplicate-address-detected && arp.opcode == 2`

## Identifying The Original IP Addresses

A crucial question we need to pose is, what were the initial IP addresses of these devices? Understanding this aids us in determining which device altered its IP address through MAC spoofing. After all, if this attack was exclusively performed via ARP, the victim machine's IP address should remain consistent. Conversely, the attacker's machine might possess a different historical IP address.

We can unearth this information within an ARP request and expedite the discovery process using this Wireshark filter.

- `(arp.opcode) && ((eth.src == 08:00:27:53:0c:ba) || (eth.dst == 08:00:27:53:0c:ba))`

![ARP Spoofing Detection](https://academy.hackthebox.com/storage/modules/229/ARP_Spoof_4.png)

In this case, we might instantly note that the MAC address `08:00:27:53:0c:ba` was initially linked to the IP address `192.168.10.5`, but this was recently switched to `192.168.10.4`. This transition is indicative of a deliberate attempt at ARP spoofing or cache poisoning.

Additionally, examining the traffic from these MAC addresses with the following Wireshark filter can prove insightful:

- `eth.addr == 50:eb:f6:ec:0e:7f or eth.addr == 08:00:27:53:0c:ba`

![ARP Spoofing Detection](https://academy.hackthebox.com/storage/modules/229/ARP_Spoof_5.png)

Right off the bat, we might notice some inconsistencies with TCP connections. If TCP connections are consistently dropping, it's an indication that the attacker is not forwarding traffic between the victim and the router.

If the attacker is, in fact, forwarding the traffic and is operating as a man-in-the-middle, we might observe identical or nearly symmetrical transmissions from the victim to the attacker and from the attacker to the router.

# ARP Scanning & Denial-of-Service

We might discern additional aberrant behaviors within the ARP requests and replies. It is common knowledge that poisoning and spoofing form the core of most ARP-based `denial-of-service (DoS)`and `man-in-the-middle (MITM)` attacks. However, adversaries could also exploit ARP for information gathering. Thankfully, we possess the skills to detect and evaluate these tactics following similar procedures.

## ARP Scanning Signs

Some typical red flags indicative of ARP scanning are:

1. `Broadcast ARP requests sent to sequential IP addresses (.1,.2,.3,...)`
2. `Broadcast ARP requests sent to non-existent hosts`
3. `Potentially, an unusual volume of ARP traffic originating from a malicious or compromised host`

## Finding ARP Scanning

Without delay, if we were to open the related traffic capture file (`ARP_Scan.pcapng`) in Wireshark and apply the filter `arp.opcode`, we might observe the following:

![ARP Scanning](https://academy.hackthebox.com/storage/modules/229/ARP_Scan_1.png)

It's possible to detect that indeed ARP requests are being propagated by a single host to all IP addresses in a sequential manner. This pattern is symptomatic of ARP scanning and is a common feature of widely-used scanners such as `Nmap`.

Furthermore, we may discern that active hosts respond to these requests via their ARP replies. This could signal the successful execution of the information-gathering tactic by the attacker.

## Identifying Denial-of-Service

**Related PCAP File(s)**:

- `ARP_Poison.pcapng`

An attacker can exploit ARP scanning to compile a list of live hosts. Upon acquiring this list, the attacker might alter their strategy to deny service to all these machines. Essentially, they will strive to contaminate an entire subnet and manipulate as many ARP caches as possible. This strategy is also plausible for an attacker seeking to establish a man-in-the-middle position.

![ARP DoS](https://academy.hackthebox.com/storage/modules/229/ARP_DoS_1.png)

Promptly, we might note that the attacker's ARP traffic may shift its focus towards declaring new physical addresses for all live IP addresses. The intent here is to corrupt the router's ARP cache.

Conversely, we may witness the duplicate allocation of `192.168.10.1` to client devices. This indicates that the attacker is attempting to corrupt the ARP cache of these victim devices with the intention of obstructing traffic in both directions.

![ARP DoS 2](https://academy.hackthebox.com/storage/modules/229/ARP_DoS_2.png)

## Responding To ARP Attacks

Upon identifying any of these ARP-related anomalies, we might question the suitable course of action to counter these threats. Here are a couple of possibilities:

1. `Tracing and Identification`: First and foremost, the attacker's machine is a physical entity located somewhere. If we manage to locate it, we could potentially halt its activities. On occasions, we might discover that the machine orchestrating the attack is itself compromised and under remote control.
2. `Containment`: To stymie any further exfiltration of information by the attacker, we might contemplate disconnecting or isolating the impacted area at the switch or router level. This action could effectively terminate a DoS or MITM attack at its source.

Link layer attacks often fly under the radar. While they may seem insignificant to identify and investigate, their detection could be pivotal in preventing the exfiltration of data from higher layers of the OSI model.