# TCP Handshake Abnormalities

Innately, when attackers are gaining information on our TCP services, we might notice a few odd behaviors during our traffic analysis efforts. Firstly, let's consider how normal TCP connections work with their 3-way handshake.

![TCP Handshake](https://academy.hackthebox.com/storage/modules/229/tcp_handshake_1.jpg)

To initiate a TCP connection for whatever purpose the client first sends the machine it is attempting to connect to a TCP SYN request to begin the TCP connection.

If this port is open, and in fact able to be connected to, the machine responds with a TCP SYN/ACK to acknowledge that the connection is valid and able to be used. However, we should consider all TCP flags.

|**Flags**|**Description**|
|---|---|
|`URG (Urgent)`|This flag is to denote urgency with the current data in stream.|
|`ACK (Acknowledgement)`|This flag acknowledges receipt of data.|
|`PSH (Push)`|This flag instructs the TCP stack to immediately deliver the received data to the application layer, and bypass buffering.|
|`RST (Reset)`|This flag is used for termination of the TCP connection (we will dive into hijacking and RST attacks soon).|
|`SYN (Synchronize)`|This flag is used to establish an initial connection with TCP.|
|`FIN (Finish)`|This flag is used to denote the finish of a TCP connection. It is used when no more data needs to be sent.|
|`ECN (Explicit Congestion Notification)`|This flag is used to denote congestion within our network, it is to let the hosts know to avoid unnecessary re-transmissions.|

As such, when we are performing our traffic analysis efforts we can look for the following strange conditions:

1. `Too many flags of a kind or kinds` - This could show us that scanning is occuring within our network.
2. `The usage of different and unusual flags` - Sometimes this could indicate a TCP RST attack, hijacking, or simply some form of control evasion for scanning.
3. `Solo host to multiple ports, or solo host to multiple hosts` - Easy enough, we can find scanning as we have done before by noticing where these connections are going from one host. In a lot of cases, we may even need to consider decoy scans and random source attacks.

## Excessive SYN Flags

Right away one of the traffic patterns that we can notice is too many SYN flags. This is a prime example of nmap scanning. Simply put, the adversary will send TCP SYN packets to the target ports. In the case where our port is open, our machine will respond with a SYN-ACK packet to continue the handshake, which will then be met by an RST from the attackers scanner. However, we can get lost in the RSTs here as our machine will respond with RST for closed ports.

![SYN Scanning](https://academy.hackthebox.com/storage/modules/229/1-TCPhandshake.png)

However it is worth noting that there are two primary scan types we might detect that use the SYN flag. These are:

1. `SYN Scans` - In these scans the behaviour will be as we see, however the attacker will pre-emptively end the handshake with the RST flag.
2. `SYN Stealth Scans` - In this case the attacker will attempt to evade detection by only partially completing the TCP handshake.

## No Flags

On the opposite side of things, the attacker might send no flags. This is what is commonly referrred to as a NULL scan. In a NULL scan an attacker sends TCP packets with no flags. TCP connections behave like the following when a NULL packet is received.

1. `If the port is open` - The system will not respond at all since there is no flags.
2. `If the port is closed` - The system will respond with an RST packet.

As such a NULL scan might look like the following.

![Null Scanning](https://academy.hackthebox.com/storage/modules/229/2-TCPhandshake.png)

## Too Many ACKs

On the other hand, we might notice an excessive amount of acknowledgements between two hosts. In this case the attacker might be employing the usage of an ACK scan. In the case of an ACK scan TCP connections will behave like the following.

1. `If the port is open` - The affected machine will either not respond, or will respond with an RST packet.
2. `If the port is closed` - The affected machine will respond with an RST packet.

So, we might see the following traffic which would indicate an ACK scan.

![ACK Scanning](https://academy.hackthebox.com/storage/modules/229/3-TCPhandshake.png)

## Excessive FINs

Using another part of the handshake, an attacker might utilize a FIN scan. In this case, all TCP packets will be marked with the FIN flag. We might notice the following behavior from our affected machine.

1. `If the port is open` - Our affected machine simply will not respond.
2. `If the port is closed` - Our affected machine will respond with an RST packet.

![FIN Scanning](https://academy.hackthebox.com/storage/modules/229/4-TCPhandshake.png)

## Just too many flags

Let's say the attacker just wanted to throw spaghetti at the wall. In that case, they might utilize a Xmas tree scan, which is when they put all TCP flags on their transmissions. Similarly, our affected host might respond like the following when all flags are set.

1. `If the port is open` - The affected machine will not respond, or at least it will with an RST packet.
2. `If the port is closed` - The affected machine will respond with an RST packet.

Xmas tree scans are pretty easy to spot and look like the following.

![Xmas Tree Scanning](https://academy.hackthebox.com/storage/modules/229/5-TCPhandshake.png)


# TCP Connection Resets & Hijacking

Unfortunately, TCP does not provide the level of protection to prevent our hosts from having their connections terminated or hijacked by an attacker. As such, we might notice that a connection gets terminated by an RST packet, or hijacked through connection hijacking.

## TCP Connection Termination

Suppose an adversary wanted to cause denial-of-service conditions within our network. They might employ a simple TCP RST Packet injection attack, or TCP connection termination in simple terms.

This attack is a combination of a few conditions:

1. `The attacker will spoof the source address to be the affected machine's`
2. `The attacker will modify the TCP packet to contain the RST flag to terminate the connection`
3. `The attacker will specify the destination port to be the same as one currently in use by one of our machines.`

As such, we might notice an excessive amount of packets going to one port.

![TCP RST Attacks](https://academy.hackthebox.com/storage/modules/229/1-RST.png)

One way we can verify that this is indeed a TCP RST attack is through the physical address of the transmitter of these TCP RST packets. Suppose, the IP address 192.168.10.4 is registered to aa:aa:aa:aa:aa:aa in our network device list, and we notice an entirely different MAC sending these like the following.

![TCP RST Attacks](https://academy.hackthebox.com/storage/modules/229/2-RST.png)

This would indicate malicious activity within our network, and we could conclude that this is likely a TCP RST Attack. However, it is worth noting that an attacker might spoof their MAC address in order to further evade detection. In this case, we could notice retransmissions and other issues as we saw in the ARP poisoning section.

## TCP Connection Hijacking

For more advanced actors, they might employ TCP connection hijacking. In this case the attacker will actively monitor the target connection they want to hijack.

The attacker will then conduct sequence number prediction in order to inject their malicious packets in the correct order. During this injection they will spoof the source address to be the same as our affected machine.

The attacker will need to block ACKs from reaching the affected machine in order to continue the hijacking. They do this either through delaying or blocking the ACK packets. As such, this attack is very commonly employed with ARP poisoning, and we might notice the following in our traffic analysis.

![TCP Connection Hijacking](https://academy.hackthebox.com/storage/modules/229/4-RST.png)

