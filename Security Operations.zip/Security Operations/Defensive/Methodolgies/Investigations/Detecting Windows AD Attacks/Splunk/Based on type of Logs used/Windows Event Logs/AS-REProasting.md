### Relevant Pages:
[[Security Operations/Defensive/Active Directory/AD Attacks/AS-REProasting|How AS-REProasting Attacks work]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/AS-REProasting|AS-REProasting Detection and Prevention with Windows Event Logs]]
## AS-REPRoasting

`ASREPRoasting` is a technique used in Active Directory environments to target user accounts without pre-authentication enabled. In Kerberos, pre-authentication is a security feature requiring users to prove their identity before the TGT is issued. However, certain user accounts, such as those with unconstrained delegation, do not have pre-authentication enabled, making them susceptible to ASREPRoasting attacks.

![](https://academy.hackthebox.com/storage/modules/233/image40.png)

#### Attack Steps:

- `Identify Target User Accounts`: The attacker identifies user accounts without pre-authentication enabled. The following is a code snippet from `Rubeus` that is related to this step.![](https://academy.hackthebox.com/storage/modules/233/image13.png)
- `Request AS-REQ Service Tickets`: The attacker initiates an AS-REQ service ticket request for each identified target user account. The following is a code snippet from `Rubeus` that is related to this step.![](https://academy.hackthebox.com/storage/modules/233/image24.png)
- `Offline Brute-Force Attack`: The attacker captures the encrypted TGTs and employs offline brute-force techniques to attempt to crack the password hashes.

#### Kerberos Pre-Authentication

`Kerberos pre-authentication` is an additional security mechanism in the Kerberos authentication protocol enhancing user credentials protection during the authentication process. When a user tries to access a network resource or service, the client sends an authentication request AS-REQ to the KDC.

If pre-authentication is enabled, this request also contains an encrypted timestamp (`pA-ENC-TIMESTAMP`). The KDC attempts to decrypt this timestamp using the user password hash and, if successful, issues a TGT to the user.

![](https://academy.hackthebox.com/storage/modules/233/image79.png)

When pre-authentication is disabled, there is no timestamp validation by the KDC, allowing users to request a TGT ticket without knowing the user password.

![](https://academy.hackthebox.com/storage/modules/233/image78.png)

#### AS-REPRoasting Detection Opportunities

Similar to Kerberoasting, the initial phase of AS-REPRoasting involves identifying user accounts with unconstrained delegation enabled or accounts without pre-authentication, which can be detected by LDAP monitoring.

Kerberos authentication `Event ID 4768 (TGT Request)` contains a `PreAuthType` attribute in the additional information part of the event indicating whether pre-authentication is enabled for an account.

## Detecting AS-REPRoasting With Splunk

Now let's explore how we can identify AS-REPRoasting, using Splunk.

#### Detecting AS-REPRoasting - Querying Accounts With Pre-Auth Disabled

**Timeframe**: `earliest=1690392745 latest=1690393283`

  Detecting Kerberoasting/AS-REProasting

```shell-session
index=main earliest=1690392745 latest=1690393283 source="WinEventLog:SilkService-Log" 
| spath input=Message 
| rename XmlEventData.* as * 
| table _time, ComputerName, ProcessName, DistinguishedName, SearchFilter 
| search SearchFilter="*(samAccountType=805306368)(userAccountControl:1.2.840.113556.1.4.803:=4194304)*"
```

![](https://academy.hackthebox.com/storage/modules/233/11.png)

#### Detecting AS-REPRoasting - TGT Requests For Accounts With Pre-Auth Disabled

**Timeframe**: `earliest=1690392745 latest=1690393283`

  Detecting Kerberoasting/AS-REProasting

```shell-session
index=main earliest=1690392745 latest=1690393283 source="WinEventLog:Security" EventCode=4768 Pre_Authentication_Type=0
| rex field=src_ip "(\:\:ffff\:)?(?<src_ip>[0-9\.]+)"
| table _time, src_ip, user, Pre_Authentication_Type, Ticket_Options, Ticket_Encryption_Type
```

![](https://academy.hackthebox.com/storage/modules/233/12.png)

**Search Breakdown**:

- `index=main earliest=1690392745 latest=1690393283 source="WinEventLog:Security" EventCode=4768 Pre_Authentication_Type=0`: Filters the search to only include events from the `main` index that occurred between the specified earliest and latest epoch timestamps. It further filters the search to only include events with a source of `WinEventLog:Security`, an `EventCode` of `4768`, and a `Pre_Authentication_Type`of `0`.
- `| rex field=src_ip "(\:\:ffff\:)?(?<src_ip>[0-9\.]+)"`: Uses a regular expression to extract the `src_ip`(source IP address) field. The expression matches an optional `"::ffff:"` prefix followed by an IP address in dotted decimal notation. This step handles IPv4-mapped IPv6 addresses by extracting the IPv4 portion.
- `| table _time, src_ip, user, Pre_Authentication_Type, Ticket_Options, Ticket_Encryption_Type`: Displays the remaining events in tabular format with the specified fields.