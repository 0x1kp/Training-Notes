### Relevant Pages:
[[Security Operations/Defensive/Active Directory/AD Attacks/Coercing Attacks and Unconstrained Delegation|How Coercing Attacks and UnConstrained Delegation Attacks work]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/Coercing Attacks and Unconstrained Delegation|Coercing Attacks and UnConstrained Delegation Detection and Prevention with Windows Event Logs]]
## Unconstrained Delegation

`Unconstrained Delegation` is a privilege that can be granted to User Accounts or Computer Accounts in an Active Directory environment, allowing a service to authenticate to another resource on behalf of `any` user. This might be necessary when, for example, a web server requires access to a database server to make changes on a user's behalf.

![](https://academy.hackthebox.com/storage/modules/233/image49.png)

#### Attack Steps:

- The attacker identifies systems on which Unconstrained Delegation is enabled for service accounts.![](https://academy.hackthebox.com/storage/modules/233/image19.png)
- The attacker gains access to a system with Unconstrained Delegation enabled.
- The attacker extracts Ticket Granting Ticket (TGT) tickets from the memory of the compromised system using tools such as `Mimikatz`.![](https://academy.hackthebox.com/storage/modules/233/image3.png)

#### Kerberos Authentication With Unconstrained Delegation

When Unconstrained Delegation is enabled, the main difference in Kerberos Authentication is that when a user requests a TGS ticket for a remote service, the Domain Controller will embed the user's TGT into the service ticket. When connecting to the remote service, the user will present not only the TGS ticket but also their own TGT. When the service needs to authenticate to another service on behalf of the user, it will present the user's TGT ticket, which the service received with the TGS ticket.

![](https://academy.hackthebox.com/storage/modules/233/image51.png)

#### Unconstrained Delegation Attack Detection Opportunities

PowerShell commands and LDAP search filters used for Unconstrained Delegation discovery can be detected by monitoring PowerShell script block logging (`Event ID 4104`) and LDAP request logging.

The main goal of an Unconstrained Delegation attack is to retrieve and reuse TGT tickets, so Pass-the-Ticket detection can be used as well.

Let's now navigate to the bottom of this section and click on "Click here to spawn the target system!". Then, access the Splunk interface at http://[Target IP]:8000 and launch the Search & Reporting Splunk application. The vast majority of searches covered from this point up to end of this section can be replicated inside the target, offering a more comprehensive grasp of the topics presented. 

## Detecting Unconstrained Delegation Attacks With Splunk

Now let's explore how we can identify Unconstrained Delegation attacks, using Splunk.

**Timeframe**: `earliest=1690544538 latest=1690544540`

  Detecting Unconstrained Delegation/Constrained Delegation Attacks

```shell-session
index=main earliest=1690544538 latest=1690544540 source="WinEventLog:Microsoft-Windows-PowerShell/Operational" EventCode=4104 Message="*TrustedForDelegation*" OR Message="*userAccountControl:1.2.840.113556.1.4.803:=524288*" 
| table _time, ComputerName, EventCode, Message
```

![](https://academy.hackthebox.com/storage/modules/233/20.png)