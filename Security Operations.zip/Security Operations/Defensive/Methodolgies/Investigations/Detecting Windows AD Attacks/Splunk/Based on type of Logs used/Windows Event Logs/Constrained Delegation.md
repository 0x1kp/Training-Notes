### Relevant Pages:
[[Security Operations/Defensive/Active Directory/AD Attacks/Kerberos Constrained Delegation|How Kerberos Constrained Delegation attacks work]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/Kerberos Constrained Delegation|Kerberos Constrained Delegation Detection and Prevention with Windows Event Logs]]
## Constrained Delegation

`Constrained Delegation` is a feature in Active Directory that allows services to delegate user credentials only to specified resources, reducing the risk associated with Unconstrained Delegation. Any user or computer accounts that have service principal names (SPNs) set in their `msDS-AllowedToDelegateTo` property can impersonate any user in the domain to those specific SPNs.

![](https://academy.hackthebox.com/storage/modules/233/image26.png)

#### Attack Steps:

- The attacker identifies systems where Constrained Delegation is enabled and determines the resources to which they are allowed to delegate.![](https://academy.hackthebox.com/storage/modules/233/image35.png)
- The attacker gains access to the TGT of the principal (user or computer). The TGT can be extracted from memory (Rubeus dump) or requested with the principal's hash.![](https://academy.hackthebox.com/storage/modules/233/image64.png)
- The attacker uses the S4U technique to impersonate a high-privileged account to the targeted service (requesting a TGS ticket).![](https://academy.hackthebox.com/storage/modules/233/image48.png)
- The attacker injects the requested ticket and accesses targeted services as the impersonated user.![](https://academy.hackthebox.com/storage/modules/233/image60.png)

#### Kerberos Protocol Extensions - Service For User

`Service for User to Self (S4U2self)` and `Service for User to Proxy (S4U2proxy)` allow a service to request a ticket from the Key Distribution Center (KDC) on behalf of a user. S4U2self allows a service to obtain a TGS for itself on behalf of a user, while S4U2proxy allows the service to obtain a TGS on behalf of a user for a second service.

S4U2self was designed to enable a user to request a TGS ticket when another method of authentication was used instead of Kerberos. Importantly, this TGS ticket can be requested on behalf of any user, for example, an Administrator.

![](https://academy.hackthebox.com/storage/modules/233/image29.png)

S4U2proxy was designed to take a forwardable ticket and use it to request a TGS ticket to any SPN specified in the `msds-allowedtodelegateto` options for the user specified in the S4U2self part.

With a combination of S4U2self and S4U2proxy, an attacker can impersonate any user to service principal names (SPNs) set in `msDS-AllowedToDelegateTo` properties.

#### Constrained Delegation Attack Detection Opportunities

Similar to Unconstrained Delegation, it is possible to detect PowerShell commands and LDAP requests aimed at discovering vulnerable Constrained Delegation users and computers.

To request a TGT ticket for a principal, as well as a TGS ticket using the S4U technique, Rubeus makes connections to the Domain Controller. This activity can be detected as an unusual process network connection to TCP/UDP port `88` (Kerberos).

## Detecting Constrained Delegation Attacks With Splunk

Now let's explore how we can identify Constrained Delegation attacks, using Splunk.

#### Detecting Constrained Delegation Attacks - Leveraging PowerShell Logs

**Timeframe**: `earliest=1690544553 latest=1690562556`

  Detecting Unconstrained Delegation/Constrained Delegation Attacks

```shell-session
index=main earliest=1690544553 latest=1690562556 source="WinEventLog:Microsoft-Windows-PowerShell/Operational" EventCode=4104 Message="*msDS-AllowedToDelegateTo*" 
| table _time, ComputerName, EventCode, Message
```

![](https://academy.hackthebox.com/storage/modules/233/21.png)

#### Detecting Constrained Delegation Attacks - Leveraging Sysmon Logs

**Timeframe**: `earliest=1690562367 latest=1690562556`

  Detecting Unconstrained Delegation/Constrained Delegation Attacks

```shell-session
index=main earliest=1690562367 latest=1690562556 source="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" 
| eventstats values(process) as process by process_id
| where EventCode=3 AND dest_port=88
| table _time, Computer, dest_ip, dest_port, Image, process
```

![](https://academy.hackthebox.com/storage/modules/233/22.png)