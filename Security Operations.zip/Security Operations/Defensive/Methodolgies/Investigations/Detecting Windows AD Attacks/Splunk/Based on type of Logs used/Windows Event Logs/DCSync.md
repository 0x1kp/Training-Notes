### Relevant Pages:
[[Security Operations/Defensive/Active Directory/AD Attacks/DCSync|How DCSync Attacks work]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/DCSync|DCSync Detection and Prevention with Windows Event Viewer]]
## DCSync

`DCSync` is a technique exploited by attackers to extract password hashes from Active Directory Domain Controllers (DCs). This method capitalizes on the `Replication Directory Changes` permission typically granted to domain controllers, enabling them to read all object attributes, including password hashes. Members of the Administrators, Domain Admins, and Enterprise Admin groups, or computer accounts on the domain controller, have the capability to execute DCSync to extract password data from Active Directory. This data may encompass both current and historical hashes of potentially valuable accounts, such as KRBTGT and Administrators.

#### Attack Steps:

- The attacker secures administrative access to a domain-joined system or escalates privileges to acquire the requisite rights to request replication data.
- Utilizing tools such as Mimikatz, the attacker requests domain replication data by using the DRSGetNCChanges interface, effectively mimicking a legitimate domain controller.![](https://academy.hackthebox.com/storage/modules/233/image73.png)
- The attacker may then craft Golden Tickets, Silver Tickets, or opt to employ Pass-the-Hash/Overpass-the-Hash attacks.

#### DCSync Detection Opportunities

`DS-Replication-Get-Changes` operations can be recorded with `Event ID 4662`. However, an additional `Audit Policy Configuration` is needed since it is not enabled by default (Computer Configuration/Windows Settings/Security Settings/Advanced Audit Policy Configuration/DS Access).

![](https://academy.hackthebox.com/storage/modules/233/image72.png)

Seek out events containing the property `{1131f6aa-9c07-11d1-f79f-00c04fc2dcd2}`, corresponding to `DS-Replication-Get-Changes`, as Event `4662` solely consists of GUIDs.

Let's now navigate to the bottom of this section and click on "Click here to spawn the target system!". Then, access the Splunk interface at http://[Target IP]:8000 and launch the Search & Reporting Splunk application. The vast majority of searches covered from this point up to end of this section can be replicated inside the target, offering a more comprehensive grasp of the topics presented. 

## Detecting DCSync With Splunk

Now let's explore how we can identify DCSync, using Splunk.

**Timeframe**: `earliest=1690544278 latest=1690544280`

  Detecting DCSync/DCShadow

```shell-session
index=main earliest=1690544278 latest=1690544280 EventCode=4662 Message="*Replicating Directory Changes*"
| rex field=Message "(?P<property>Replicating Directory Changes.*)"
| table _time, user, object_file_name, Object_Server, property
```

![](https://academy.hackthebox.com/storage/modules/233/23.png)