[[Security Operations/Defensive/Active Directory/AD Attacks/Kerberoasting|How Kerberoasting works]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/Kerberoasting|Detecting Kerberoasting with Windows Event Logs]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Splunk/Based on type of Logs used/Windows Event Logs/Kerberoasting|Detecting Kerberoasting with Windows Event Logs on Splunk]]

In 2016, a number of blog posts and articles emerged discussing the tactic of querying Service Principal Name (SPN) accounts and their corresponding tickets, an attack that came to be known as `Kerberoasting`. By possessing just one legitimate user account and its password, an attacker could retrieve the SPN tickets and attempt to break them offline.

After examining numerous resources on kerberoasting, it is evident that `RC4` is utilized for ticket encryption behind the scenes. We will exploit this underpinning as a detection point in this section.

**Evidence Source**: [https://www.ired.team/offensive-security-experiments/active-directory-kerberos-abuse/t1208-kerberoasting](https://www.ired.team/offensive-security-experiments/active-directory-kerberos-abuse/t1208-kerberoasting)

#### How Kerberoasting Traffic Looks Like

![](https://academy.hackthebox.com/storage/modules/233/109.png)

Let's now navigate to the bottom of this section and click on "Click here to spawn the target system!". Then, access the Splunk interface at https://[Target IP]:8000 and launch the Search & Reporting Splunk application. The vast majority of searches covered from this point up to end of this section can be replicated inside the target, offering a more comprehensive grasp of the topics presented. 

Additionally, we can access the spawned target via RDP as outlined below. All files, logs, and PCAP files related to the covered attacks can be found in the /home/htb-student and /home/htb-student/module_files directories. 

  Detecting Kerberoasting

```shell-session
ukejelam@htb[/htb]$ xfreerdp /u:htb-student /p:'HTB_@cademy_stdnt!' /v:[Target IP] /dynamic-resolution
```

#### Related Evidence

- **Related Directory**: `/home/htb-student/module_files/kerberoast`
- **Related Splunk Index**: `kerberoast`
- **Related Splunk Sourcetype**: `bro:kerberos:json`

---

## Detecting Kerberoasting With Splunk & Zeek Logs

Now let's explore how we can identify Kerberoasting, using Splunk and Zeek logs.

  Detecting Kerberoasting

```shell-session
index="kerberoast"  sourcetype="bro:kerberos:json"
request_type=TGS cipher="rc4-hmac" 
forwardable="true" renewable="true"
| table _time, id.orig_h, id.resp_h, request_type, cipher, forwardable, renewable, client, service
```

![](https://academy.hackthebox.com/storage/modules/233/110.png)