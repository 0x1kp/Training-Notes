### Relevant Pages:
[[Security Operations/Defensive/Active Directory/AD Attacks/Golden Ticket|How Golden Ticket Attacks work]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Splunk/Based on type of Logs used/Zeek Logs/Golden Ticket|Golden Ticket Detection with Splunk using Zeek Logs]]
[[Security Operations/Defensive/Methodolgies/Investigations/Detecting Windows AD Attacks/Windows Event Logs & Sysmon/Golden Ticket|Golden Ticket Detection and Prevention with Windows Event Viewer]]
## Golden Ticket

A `Golden Ticket` attack is a potent method where an attacker forges a Ticket Granting Ticket (TGT) to gain unauthorized access to a Windows Active Directory domain as a domain administrator. The attacker creates a TGT with arbitrary user credentials and then uses this forged ticket to impersonate a domain administrator, thereby gaining full control over the domain. The Golden Ticket attack is stealthy and persistent, as the forged ticket has a long validity period and remains valid until it expires or is revoked.

#### Attack Steps:

- The attacker extracts the NTLM hash of the KRBTGT account using a `DCSync`attack (alternatively, they can use `NTDS.dit` and `LSASS process dumps` on the Domain Controller).![](https://academy.hackthebox.com/storage/modules/233/image74.png)
- Armed with the `KRBTGT` hash, the attacker forges a TGT for an arbitrary user account, assigning it domain administrator privileges.![](https://academy.hackthebox.com/storage/modules/233/image17.png)
- The attacker injects the forged TGT in the same manner as a Pass-the-Ticket attack.

#### Golden Ticket Detection Opportunities

Detecting Golden Ticket attacks can be challenging, as the TGT can be forged offline by an attacker, leaving virtually no traces of `Mimikatz` execution. One option is to monitor common methods of extracting the `KRBTGT` hash:

- `DCSync attack`
- `NTDS.dit file access`
- `LSASS memory read on the domain controller (Sysmon Event ID 10)`

From another standpoint, a Golden Ticket is just another ticket for Pass-the-Ticket detection.

Let's now navigate to the bottom of this section and click on "Click here to spawn the target system!". Then, access the Splunk interface at http://[Target IP]:8000 and launch the Search & Reporting Splunk application. The vast majority of searches covered from this point up to end of this section can be replicated inside the target, offering a more comprehensive grasp of the topics presented. 

## Detecting Golden Tickets With Splunk (Yet Another Ticket To Be Passed Approach)

Now let's explore how we can identify Golden Tickets, using Splunk.

**Timeframe**: `earliest=1690451977 latest=1690452262`

  Detecting Golden Tickets/Silver Tickets

```shell-session
index=main earliest=1690451977 latest=1690452262 source="WinEventLog:Security" user!=*$ EventCode IN (4768,4769,4770) 
| rex field=user "(?<username>[^@]+)"
| rex field=src_ip "(\:\:ffff\:)?(?<src_ip_4>[0-9\.]+)"
| transaction username, src_ip_4 maxspan=10h keepevicted=true startswith=(EventCode=4768)
| where closed_txn=0
| search NOT user="*$@*"
| table _time, ComputerName, username, src_ip_4, service_name, category
```

![](https://academy.hackthebox.com/storage/modules/233/17.png)