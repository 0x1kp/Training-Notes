[Velociraptor](https://github.com/Velocidex/velociraptor) is a potent tool for gathering host-based information using Velociraptor Query Language (VQL) queries. Beyond this, Velociraptor can execute `Hunts` to amass various artifacts. A frequently utilized artifact is the `Windows.KapeFiles.Targets`. While KAPE (Kroll Artifact Parser and Extractor) itself isn't open-source, its file collection logic, encoded in YAML, is accessible via the [KapeFiles project](https://github.com/EricZimmerman/KapeFiles). This approach is a staple in Rapid Triage.

To utilize Velociraptor for KapeFiles artifacts:

- Initiate a new Hunt.![](https://academy.hackthebox.com/storage/modules/237/vel0.png)

    ![](https://academy.hackthebox.com/storage/modules/237/image33.png)
    
- Choose `Windows.KapeFiles.Targets` as the artifacts for collection.![](https://academy.hackthebox.com/storage/modules/237/image64.png)
    
- Specify the collection to use.![](https://academy.hackthebox.com/storage/modules/237/vel1.png)
    
    ![](https://academy.hackthebox.com/storage/modules/237/image19.png)
    
- Click on `Launch` to start the hunt.![](https://academy.hackthebox.com/storage/modules/237/image27.png)
    
- Once completed, download the results.![](https://academy.hackthebox.com/storage/modules/237/image90.png)
    

Extracting the archive will reveal files related to the collected artifacts and all gathered files.

![](https://academy.hackthebox.com/storage/modules/237/image12_.png)

![](https://academy.hackthebox.com/storage/modules/237/image37.png)

For remote memory dump collection using Velociraptor:

- Start a new Hunt, but this time, select the `Windows.Memory.Acquisition` artifact.![](https://academy.hackthebox.com/storage/modules/237/image92.png)
- After the Hunt concludes, download the resulting archive. Within, you'll find a file named `PhysicalMemory.raw`, containing the memory dump.![](https://academy.hackthebox.com/storage/modules/237/image45.png)
