
**Example 1: Forensic Imaging with FTK Imager**

Let's now see a demonstration of utilizing `FTK Imager` to craft a disk image. Be mindful that you'll require an auxiliary storage medium, like an external hard drive or USB flash drive, to save the resultant disk image.

- Select `File` -> `Create Disk Image`.![](https://academy.hackthebox.com/storage/modules/237/image11.png)
- Next, select the media source. Typically, it's either `Physical Drive` or `Logical Drive`.![](https://academy.hackthebox.com/storage/modules/237/image1.png)
- Choose the drive from which you wish to create an image.![](https://academy.hackthebox.com/storage/modules/237/image3.png)
- Specify the destination for the image.![](https://academy.hackthebox.com/storage/modules/237/image7.png)
- 
- Select the desired image type.
- ![](https://academy.hackthebox.com/storage/modules/237/image4.png)
- 
- Input evidence details.
- ![](https://academy.hackthebox.com/storage/modules/237/image10.png)
- Choose the destination folder and filename for the image. At this step, you can also adjust settings for image fragmentation and compression.
- ![](https://academy.hackthebox.com/storage/modules/237/image8.png)
- Once all settings are confirmed, click `Start`.
- ![](https://academy.hackthebox.com/storage/modules/237/image2.png)
- You'll observe the progress of the imaging.![](https://academy.hackthebox.com/storage/modules/237/image12.png)
- If you opted to verify the image, you'll also see the verification progress.![](https://academy.hackthebox.com/storage/modules/237/image6.png)
- After the image has been verified, you'll receive an imaging summary. Now, you're prepared to analyze this dump.
- ![](https://academy.hackthebox.com/storage/modules/237/image9.png)