Enter [Autopsy](https://www.autopsy.com/): a user-friendly forensic platform built atop the open-source Sleuth Kit toolset. It mirrors many features you'd find in its commercial counterparts: timeline assessments, keyword hunts, web and email artifact retrievals, and the ability to sift results based on known malicious file hashes.

Once you've loaded a forensic image and processed the data, you'll see the forensic artifacts neatly organized on the side panel. From here, you can:

![](https://academy.hackthebox.com/storage/modules/237/image16.png)

- Dive into `Data Sources` to explore files and directories.![](https://academy.hackthebox.com/storage/modules/237/image1_.png)
    
- Examine `Web Artifacts`.![](https://academy.hackthebox.com/storage/modules/237/image80.png)
    
- Check `Attached Devices`.![](https://academy.hackthebox.com/storage/modules/237/image8_.png)
    
- Recover `Deleted Files`.![](https://academy.hackthebox.com/storage/modules/237/image51.png)
    
- Conduct `Keyword Searches`.![](https://academy.hackthebox.com/storage/modules/237/image75.png)
    
    ![](https://academy.hackthebox.com/storage/modules/237/image23.png)
    
- Use `Keyword Lists` for targeted searches.![](https://academy.hackthebox.com/storage/modules/237/image72.png)
    
    ![](https://academy.hackthebox.com/storage/modules/237/image52.png)
    
- Undertake `Timeline Analysis` to map out events.![](https://academy.hackthebox.com/storage/modules/237/image99.png)