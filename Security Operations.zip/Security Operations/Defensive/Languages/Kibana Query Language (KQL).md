Kibana Query Language (KQL) is a query language designed specifically for searching and analyzing data in Kibana.

KQL queries are composed of field:value pairs, with the field representing the data's attribute and the value representing the data you're searching for
	event.code: 4625 filters for logs with the Windows event code 4625

KQL supports Free Text Speech
	i.e. you can search for specific text and it'll filter the logs looking for that text.
	"svc-sql1" can be typed into the search bar and it'll search all indexed logs and return all instances of "svc-sql1"

KQL supports Logical Operators
	KQL supports logical operators AND, OR, and NOT for constructing more complex queries. Parentheses can be used to group expressions and control the order of evaluation

KQL supports Wildcards and Regular Expression
	 For example: event.code:4625 AND user.name: admin* 
	 This Kibana KQL query filters data in Kibana to show events that have the Windows event code 4625 (failed login attempts) and where the username starts with "admin", such as "admin", "administrator", "admin123", etc.

To find out what data fields are available in the indexed logs, see [[What are SIEMs?#How To Identify The Available Data in Kibana|This Link]]

For step by step examples on how to use ElasticStack, see [[Elastic Introduction]]


