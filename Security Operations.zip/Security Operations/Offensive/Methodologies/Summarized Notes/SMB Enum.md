**SMB**
Samba -> Linux

**Steps**
Read config files

**Restart Samba**
Sudo systemctl restart smbd

**Connecting to Share in SMBClient**
smbclient -N -L //10.129.14.128


**Footprinting**

**NMAP**
Use -sV and -sC to enumerate, specify ports for SMB depending on target host OS


**RPCclient**
Use -U “”
Rpcclient -U “” <IP ADDRESS>
Rpcclient offers several options for SMB enum

srvinfo
enumdomains
querydominfo
netshareenumall
netsharegetinfo <share>
enumdomusers
queryuser <RID>

BruteForcing RIDS

A. BASH Script

[!bash!]$ for i in $(seq 500 1100);do rpcclient -N -U "" 10.129.14.128 -c "queryuser 0x$(printf '%x\n' $i)" | grep "User Name\|user_rid\|group_rid" && echo "";done

B. An alternative to this would be a Python script from [Impacket](https://github.com/SecureAuthCorp/impacket) called [samrdump.py](https://github.com/SecureAuthCorp/impacket/blob/master/examples/samrdump.py).

C. The information we have already obtained with rpcclient can also be obtained using other tools. For example, the [SMBMap](https://github.com/ShawnDEvans/smbmap) and [CrackMapExec](https://github.com/byt3bl33d3r/CrackMapExec) tools are also widely used and helpful for the enumeration of SMB services.

D. Another tool worth mentioning is the so-called [enum4linux-ng](https://github.com/cddmp/enum4linux-ng), which is based on an older tool, enum4linux. This tool automates many of the queries, but not all, and can return a large amount of information.


SMBMap
smbmap -H 10.129.14.128

CrackMapExec
crackmapexec smb 10.129.14.128 --shares -u '' -p ''

Enum4Linux

Installation
git clone [https://github.com/cddmp/enum4linux-ng.git](https://github.com/cddmp/enum4linux-ng.git)
cd enum4linux-ng
Pip3 install -r requirements.txt

Enumeration
[!bash!]$ ./enum4linux-ng.py 10.129.14.128 -A