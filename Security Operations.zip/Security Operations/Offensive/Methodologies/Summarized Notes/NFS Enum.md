NFS

Network File System

- Same purpose as SMB
- Can’t communicate with SMB
- Made for Unix & Linux systems
- Based on Open Network Computing Remote Procedure Call (ONC-RPC)

NFSv2 (Operated entirely over UDP)
NFSv3 (Not compatible w v2, better error reporting, authenticates system)
NFSv4 (Uses kerberos, authenticates user, TCP/UDP port 2049)

Config file: /etc/exports

Has less options for configuration than SMB

Footprinting
TCP Ports 111 and 2049 are essential

NMAP
- Sudo Nmap <IP> -p111,2049 -sV -sC
	- sudo nmap --script nfs* 10.129.14.128 -sV -p111,2049

To show available NFS shares
showmount -e 10.129.14.128


To mount NFS Share

mkdir target-NFS
sudo mount -t nfs 10.129.14.128:/ ./target-NFS/ -o nolock
cd target-NFS

  

To unmount

sudo umount ./target-NFS