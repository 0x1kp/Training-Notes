```shell-session
sudo nmap 10.129.14.128 -sC -sV -p25
```

```shell-session
sudo nmap 10.129.14.128 -p25 --script smtp-open-relay -v
```

