#### Domain Name System
Library that resolves computer names into IP addresses

#### DNS Server types:
Root Server
Authoritative Name Server
Non-authoritative Name Server
Caching Server
Forwarding Server
Resolver

DNS is typically unencrypted which is NOT GOOD
Solutions now made for DNS encryption:
DNS over TLS (DoT)
DNS over HTTPS (DoH)

DNS also stores information (DNS Records) associated with domain etc email server.
#### DNS Records
A, AAAA, MX, NS, TXT, CNAME, PTR, SOA

#### Default Configuration
- Local DNS configuration files
- Zone files
- Reverse name resolution files

named.conf.local
named.conf.options
named.conf.log

#### Location
/etc/bind/named.conf.local

#### **Commands to enum DNS**
dig/nslookup (Dig better)