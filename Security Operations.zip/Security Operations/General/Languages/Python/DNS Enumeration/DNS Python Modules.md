# Relevant Pages:
[[DNS Security]]
[[DNS Structure]]
[[DNS Zones]]
[[Records & Queries|Records and Queries]]

Before we start coding our tool, we have to determine which modules we need and which are best suited for it. A quick search on Google will bring us to the module called "[dnspython](https://dnspython.readthedocs.io/en/latest/)". Our goal is to perform a zone transfer, and accordingly, we need to find the appropriate classes and functions to communicate with the DNS servers. Another extension that we can use to develop such tools with Python 3 is [IPython](https://ipython.org/install.html). It supports auto-completion and shows the different options in the corresponding classes and modules in an interactive Python shell.

After we have installed the module, we can import it. This module offers us the classes `Query`, `Resolver`, and `Zone`. The `dns.zone` module contains a "`from_xfr`" class. We can find this out by using the `help()`function in Python.

#### Python Help()

```shell-session
ukejelam@htb[/htb]$ ipython

In [1]: import dns.zone as dz

In [2]: help(dz.  #[1x Tab]

                 BadZone       dns           from_text()   generators    NoSOA         PY3           string_types  text_type     Zone
                 BytesIO       from_file()   from_xfr()    NoNS          os            re            sys           UnknownOrigin
```

#### Dns.Zone.From_XFR()

```shell-session
In [2]: help(dz.from_xfr) 
```

#### From_XFR() - Documentation

```shell-session
from_xfr(xfr, zone_factory=<class 'dns.zone.Zone'>, relativize=True, check_origin=True)
    Convert the output of a zone transfer generator into a zone object.

    @param xfr: The xfr generator
    @type xfr: generator of dns.message.Message objects
    @param relativize: should names be relativized?  The default is True.
    It is essential that the relativize setting matches the one specified
    to dns.query.xfr().
    @type relativize: bool
    @param check_origin: should sanity checks of the origin node be done?
    The default is True.
    @type check_origin: bool
    @raises dns.zone.NoSOA: No SOA RR was found at the zone origin
    @raises dns.zone.NoNS: No NS RRset was found at the zone origin
    @rtype: dns.zone.Zone object
```

We can also find the documentation for this on the [documentation page](https://dnspython.readthedocs.io/en/latest/zone-make.html) that describes the required parameters for the `from_xfr()` function. From the parameter "`xfr`," we will also need the `dns.query`class. So we should also note this class for later use.


```python
# Notes
import dns.zone as dz
import dns.query as dq

# axfr = dz.from_xfr(dq.xfr())
```

We need to take a closer look at the `dns.query.xfr()` function to determine which parameters are required.

#### Dns.Query.XFR()

```shell-session
In [3]: help(dq.xfr) 
```

#### XFR() - Documentation


```shell-session
Help on function xfr in module dns.query:

xfr(where, zone, rdtype=252, rdclass=1, timeout=None, port=53, keyring=None, keyname=None, relativize=True, af=None, lifetime=None, source=None, source_port=0, serial=0, use_udp=False, keyalgorithm=<DNS name HMAC-MD5.SIG-ALG.REG.INT.>)
    Return a generator for the responses to a zone transfer.

    *where*.  If the inference attempt fails, AF_INET is used.  This
    parameter is historical; you need never set it.
<SNIP>
```

Here we can see that only two variables have no value and therefore need specific parameters to perform this function.

- `where`
- `zone`

We can also find out the required parameters by executing the function. Because if we do not output any parameters, an error will occur with the description that says which parameters are needed.

#### Required Parameters


```shell-session
In [4]: dq.xfr()

---------------------------------------------------------------------------
TypeError                                 Traceback (most recent call last)
<ipython-input-14-672b143b8cfc> in <module>
----> 1 dq.xfr()

TypeError: xfr() missing 2 required positional arguments: 'where' and 'zone'
```

In this case, the variable "`where`" stands for the DNS server and the variable "`zone`" for the domain. We note this as well.


```python
# Notes
import dns.zone as dz
import dns.query as dq

# axfr = dz.from_xfr(dq.xfr(nameserver, domain))
```

## DNS Requests

We have to find out how to resolve our requests by using specific DNS servers. The easiest way with the necessary class would be "`dns.resolver`". In the [documentation](https://dnspython.readthedocs.io/en/latest/resolver-class.html), we can find the class "`Resolver`" which allows us to specify the DNS servers we want to send our requests to. Of course, we can also automatically find these DNS servers, so we do not have to change them manually. Nevertheless, we have to be careful because companies often use DNS servers from third party providers for which we usually do not have the permissions to test them. Therefore, we recommend that we specify them manually and preferably in the command line rather than in our code. To make this possible, we import another module called "`argparse`". Accordingly, we also add this information to our notes.


```python
# Notes
import dns.zone as dz
import dns.query as dq
import dns.resolver as dr
import argparse

# axfr = dz.from_xfr(dq.xfr(nameserver, domain))

# NS = dr.Resolver()
# NS.nameservers = ['ns1', 'ns2']
```


We now have to find the "NS" records for this domain, and instead of using the `dig` tool, we do it with our Python modules. In this example, we still use the domain called:

- `inlanefreight.com`

The corresponding NS servers we found by using the following code:

#### NS Records - DNS.Resolver

```shell-session
ukejelam@htb[/htb]$ python3

>>> import dns.resolver
>>> 
>>> nameservers = dns.resolver.query('inlanefreight.com', 'NS')
>>> for ns in nameservers:
...    	print('NS:', ns)
...
NS: ns1.inlanefreight.com.
NS: ns2.inlanefreight.com.
```

In summary, we have the following information now:

```python
Domain = 'inlanefreight.com'
DNS Servers = ['ns1.inlanefreight.com', 'ns2.inlanefreight.com']
```

Now we can summarize all our information and write the first lines of our code.

#### DNS-AXFR.py

```python
#!/usr/bin/env python3

# Dependencies:
# python3-dnspython

# Used Modules:
import dns.zone as dz
import dns.query as dq
import dns.resolver as dr
import argparse

# Initialize Resolver-Class from dns.resolver as "NS"
NS = dr.Resolver()

# Target domain
Domain = 'inlanefreight.com'

# Set the nameservers that will be used
NS.nameservers = ['ns1.inlanefreight.com', 'ns2.inlanefreight.com']

# List of found subdomains
Subdomains = []
```

# AXFR Function

It is always an advantage if we separate individual processes from each other and build a single function out of it. This makes it easier to debug later when errors occur, and it makes the main function more independent. It may seem irrelevant at first with such a small tool, but if we start to extend the code, and eventually, our tool grows to a size of more than 1000 lines of code, we will see this advantage. We can divide the process into the following sections:

1. We now want to create a function that tries to perform a zone transfer using the given domain and DNS servers.
    
2. If the zone transfer was successful, we want the found subdomains to be displayed directly and stored in our list.
    
3. In case an error occurs, we want to be informed about the error.

## Functions

For the `functions`, we should try to use as few passing arguments as possible. Therefore there should not be more than three arguments, because otherwise there can be a high error-proneness. So in the next example, we use the two arguments `domain` and `nameserver`, which we need for the `zone transfer`.

Again, we should determine how we define the `functions` and keep this standard. In this case, we define the functions by capitalizing all letters of them. Many people use this capitalization also for classes. Then we should add comments to the function to divide each step in the function into parts.

#### DNS-AXFR.py - Functions


```python
<SNIP>
# List of found subdomains
Subdomains = []

# Define the AXFR Function
def AXFR(domain, nameserver):

        # Try zone transfer for given domain and namerserver
		# Perform the zone transfer
        # If zone transfer was successful
        # Add found subdomains to global 'Subdomain' list
        # If zone transfer fails

# Main
if __name__=="__main__":

        # For each nameserver
        # Try AXFR
        # Print the results
        # Print each subdomain
```



## Try-Except

If a statement or an expression is written correctly in terms of its syntax, errors may occur during execution. Errors that occur during execution are called `exceptions` and are not necessarily serious. A `try` statement can contain more than one `except` block to define different actions for different exceptions. At most, one `except` block is executed. A block can only handle the exceptions that occurred in the corresponding `try` block, but not those that occur in another except the block of the same `try`statement.

#### DNS-AXFR.py - Try-Except

```python
<SNIP>
# List of found subdomains
Subdomains = []

# Define the AXFR Function
def AXFR(domain, nameserver):

        # Try zone transfer for given domain and namerserver
        try:
				# Perform the zone transfer
                axfr = dz.from_xfr(dq.xfr(nameserver, domain))
				
                # If zone transfer was successful
                # Add found subdomains to global 'Subdomain' list
				
        # If zone transfer fails
        except Exception as error:
                print(error)
                pass
```



## If-Else

With `if-else` statements, it depends on how many arguments or values we want to check simultaneously. In the best case, there should be only one value or argument to check at a time. However, if we need to check more than one argument and the line can be very long, it is recommended to write every argument in the brackets in a new line.

#### If-Else - Few Arguments

```python
# Few arguments
if (arg1 and arg2):
	# Perform specified actions
else:
	pass
```

#### If-Else - Many Arguments

```python
# Many arguments
if (arg1 
	and arg2
	and arg3
	and arg4):
	
	# Perform specified actions
else:
	pass
```

In our `DNS.py` script, we use only one tested value, and therefore we don't need multiple lines.

#### DNS-AXFR.py - If-Else

```python
<SNIP>
# List of found subdomains
Subdomains = []

# Define the AXFR Function
def AXFR(domain, nameserver):

        # Try zone transfer for given domain and namerserver
        try:
				# Perform the zone transfer
                axfr = dz.from_xfr(dq.xfr(nameserver, domain))

                # If zone transfer was successful
                if axfr:
                        print('[*] Successful Zone Transfer from {}'.format(nameserver))

                        # Add found subdomains to global 'Subdomain' list

        # If zone transfer fails
        except Exception as error:
                print(error)
                pass
```



## For-Loop

The `For` loops should always be kept as simple as possible, as they can cause errors with the number of passes, which we then have to debug manually for each entry to understand what went wrong in the loop. Therefore, we will now append each "`record`" to our predefined "`Subdomains`" list to store the subdomains we found.

#### DNS-AXFR.py


```python
<SNIP>
# List of found subdomains
Subdomains = []

# Define the AXFR Function
def AXFR(domain, nameserver):

        # Try zone transfer for given domain and namerserver
        try:
				# Perform the zone transfer
                axfr = dz.from_xfr(dq.xfr(nameserver, domain))

                # If zone transfer was successful
                if axfr:
                        print('[*] Successful Zone Transfer from {}'.format(nameserver))

                        # Add found subdomains to global 'Subdomain' list
                        for record in axfr:
                                Subdomains.append('{}.{}'.format(record.to_text(), domain))

        # If zone transfer fails
        except Exception as error:
                print(error)
                pass
```

Now we have our function, which only needs the domain and the respective name server as arguments. Next, we need the `Main function`, which passes the arguments to the `AXFR function`, executes it, and shows us the results.

# Main Function

The main function is the part of the code where the main program is running. It is essential to keep it as clear as possible, as we will most likely add more functions to our tool later. In this case, we want our tool to try a zone transfer on every DNS server we have specified. We know that the subdomains found will be added to the global subdomain list in the `AXFR()` function. So if this list is not empty, we want to see all subdomains.



## Main

If we start a Python program by calling a py file, and there we call `"__name__"`, the system assigns it to the system variable the identifier "`__main__`." However, if we import this file into another module, it gets an identifier corresponding to the file name. This construction uses a Python file as a stand-alone program, makes single elements of this file importable, and implements complex module tests. As we did with the `AXFR` function, we proceed accordingly and define the rough steps that need to be taken as comments.

#### DNS-AXFR.py

```python
<SNIP>
# Main
if __name__=="__main__":

        # For each nameserver
        # Try AXFR
        # Print the results
        # Print each subdomain
```



## For-Loop - Try AXFR

Since our `AXFR` function requires the two parameters, "domain" and "nameserver," we create a `For-loop`that executes the `AXFR` function for each nameserver specified. We use another `For-loop` combined with the `If-Else` statement in the area that will output the found subdomains. If the subdomain list, in which the `AXFR` function stores the found subdomains, is not empty, then every subdomain entry from the subdomain list should be printed.

#### DNS-AXFR.py

```python
<SNIP>
# Main
if __name__=="__main__":

        # For each nameserver
        for nameserver in NS.nameservers:

                #Try AXFR
                AXFR(Domain, nameserver)

        # Print the results
        if Subdomains is not None:
                print('-------- Found Subdomains:')

                # Print each subdomain
                for subdomain in Subdomains:
                        print('{}'.format(subdomain))

        else:
                print('No subdomains found.')
                exit()
```



## DNS-AXFR.py - Complete Code

```python
#!/usr/bin/env python3

# Dependencies:
# python3-dnspython

# Used Modules:
import dns.zone as dz
import dns.query as dq
import dns.resolver as dr
import argparse

# Initialize Resolver-Class from dns.resolver as "NS"
NS = dr.Resolver()

# Target domain
Domain = 'inlanefreight.com'

# Set the nameservers that will be used
NS.nameservers = ['ns1.inlanefreight.com', 'ns2.inlanefreight.com']

# List of found subdomains
Subdomains = []

# Define the AXFR Function
def AXFR(domain, nameserver):

        # Try zone transfer for given domain and namerserver
        try:
				# Perform the zone transfer
                axfr = dz.from_xfr(dq.xfr(nameserver, domain))

                # If zone transfer was successful
                if axfr:
                        print('[*] Successful Zone Transfer from {}'.format(nameserver))

                        # Add found subdomains to global 'Subdomain' list
                        for record in axfr:
                                Subdomains.append('{}.{}'.format(record.to_text(), domain))

        # If zone transfer fails
        except Exception as error:
                print(error)
                pass

# Main
if __name__=="__main__":

        # For each nameserver
        for nameserver in NS.nameservers:

                #Try AXFR
                AXFR(Domain, nameserver)

        # Print the results
        if Subdomains is not None:
                print('-------- Found Subdomains:')

                # Print each subdomain
                for subdomain in Subdomains:
                        print('{}'.format(subdomain))

        else:
                print('No subdomains found.')
                exit()                
```
