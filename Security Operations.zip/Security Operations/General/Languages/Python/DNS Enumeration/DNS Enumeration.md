As with any service we work with and want to find out information, it is essential to understand how DNS works to create a clear structure with the appropriate information. Since DNS can provide much information about the company's infrastructure, we can divide this information into the following categories:

- `DNS Records`
- `Subdomains`/`Hosts`
- `DNS Security`

There is a variety of techniques that can be used for this. These include:

- OSINT
- Certificate Transparency
- Zone transfer

## OSINT

The OSINT is an information procurement from publicly available and open sources. In the simplest case, we can also use search engines like `Bing`, `Yahoo`, and `Google` with the corresponding [Google Dorks](https://securitytrails.com/blog/google-hacking-techniques) of Google to filter out our results.

![](https://academy.hackthebox.com/storage/modules/27/osint-dns2.png)

Also, we can use public services such as [VirusTotal](https://www.virustotal.com/), [DNSdumpster](https://dnsdumpster.com/), [Netcraft](https://searchdns.netcraft.com/), and others to read known entries for the corresponding domain. We can use "Right-Click on the image -> View Image" to make it bigger.


#### VirusTotal

![](https://academy.hackthebox.com/storage/modules/27/virustotal.png)


#### DNSdumpster

![](https://academy.hackthebox.com/storage/modules/27/dnsdumpster.png)


#### Netcraft

![](https://academy.hackthebox.com/storage/modules/27/netcraft.png)


## Certificate Transparency

`Certificate Transparency` (`CT`) logs contain all certificates issued by a participating `Certificate Authority` (`CA`) for a specific domain. Therefore, `SSL/TLS certificates` from web servers include `domain names`, `subdomain names`, and `email addresses`. Since these logs are public and accessible to everyone, it is a valuable source for understanding the target company's infrastructure better. We can use a tool that outputs all the `CT logs` for our target domain from different sources and filtered is [ctfr.py](https://github.com/UnaPibaGeek/ctfr).

#### CTFR.py

```shell-session
ukejelam@htb[/htb]$ python3 ctfr.py -d inlanefreight.com

          ____ _____ _____ ____  
         / ___|_   _|  ___|  _ \ 
        | |     | | | |_  | |_) |
        | |___  | | |  _| |  _ < 
         \____| |_| |_|   |_| \_\
	
    Made by Sheila A. Berta (UnaPibaGeek)
	
inlanefreight.com
vc.inlanefreight.com
wlan.inlanefreight.com
afdc0102.inlanefreight.com
autodiscover.inlanefreight.com
kfdcex07.inlanefreight.com
kfdcex08.inlanefreight.com
videoconf.inlanefreight.com
<SNIP>
```

## Zone Transfer

`Zone transfer` in DNS refers to the transfer of zones to other DNS servers. This procedure is called the `Asynchronous Full Transfer Zone` (`AXFR`), as we have already learned. Since a DNS failure usually has severe consequences for a company, the `zone files` are almost without exception kept identical on several name servers. In the event of changes, it must be ensured that all servers have the same data stock. `Zone transfer` involves the mere transfer of files or records and the detection of discrepancies in the databases of the servers involved. DNS servers' configuration requires a great deal of attention because many administrators cannot always fully understand the operating principle from the technical configuration and troubleshooting. This leads to error rate and vulnerability, leading to misconfigurations and endanger the system or even the entire infrastructure by allowing the entire content of the zones to be viewed.

#### Performing DNS Zone Transfer

```shell-session
ukejelam@htb[/htb]$ dig axfr inlanefreight.com @10.129.2.67

; <<>> DiG 9.16.1-Ubuntu <<>> axfr inlanefreight.com @10.129.2.67
;; global options: +cmd
inlanefreight.com.	    3600	IN	SOA	ns1.inlanefreight.com. adm.inlanefreight.com. 8 3600 300 86400 600
inlanefreight.com.	    3600	IN	A	178.128.39.165
inlanefreight.com.   	3600	IN	A	206.189.119.186
inlanefreight.com.	    3600	IN	NS	ns1.inlanefreight.com.
inlanefreight.com.	    3600	IN	NS	ns2.inlanefreight.com.
adm.inlanefreight.com.	3600	IN	A	134.209.24.248
blog.inlanefreight.com.	3600	IN	A	134.209.24.248
<SNIP>
```